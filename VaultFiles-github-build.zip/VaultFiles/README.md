# VaultFiles

A privacy-first Android file manager with an encrypted local vault.

## Included in this build

- Modern Jetpack Compose / Material 3 interface with dynamic system colors
- Internal storage browser with folders and breadcrumb-style path display
- Quick access to Downloads, Pictures, Videos, Music, and Documents
- Search inside the current folder tree
- Sort by name, date, or size
- Create folders, rename, delete, open, share, copy, and move
- Android 11+ `MANAGE_EXTERNAL_STORAGE` flow for true file-manager access
- Legacy storage permission flow for older Android versions
- Secure local vault
  - AES-256-GCM authenticated encryption for each locked file
  - A random 256-bit vault master key
  - PIN protection via PBKDF2-HMAC-SHA256 (600,000 iterations)
  - An additional device-bound Android Keystore wrapping layer
  - Encrypted vault metadata/index
  - Optional biometric unlock using an authentication-bound Android Keystore key
  - Automatic vault lock when the app leaves the foreground
  - App backup disabled to avoid moving device-bound vault material to another phone
- No `INTERNET` permission, analytics SDK, advertising SDK, or cloud upload code

## Important behavior

When a file is locked, VaultFiles encrypts a private copy first and then removes the original. If Android or the filesystem refuses to delete the original, the app explicitly warns that the encrypted copy exists but the original must be removed manually.

Restoring a file prefers its original folder. If that folder is no longer available, the file is restored to `Downloads/VaultFiles Restored`.

The PIN is not stored. If both the PIN and usable biometric unlock are lost, encrypted files are intentionally unrecoverable.

Modern Android deliberately blocks ordinary apps, including file managers, from unrestricted access to other apps' private `Android/data` directories. VaultFiles does not attempt to bypass the Android sandbox.

## Build

Recommended:

- Android Studio with JDK 17+
- Android SDK 35 installed

Open this folder as an Android Studio project, allow Gradle to sync, then use **Build > Build APK(s)**.

The project currently uses:

- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Jetpack Compose BOM 2024.10.01
- minSdk 26
- targetSdk / compileSdk 35

## Package

`com.vaultfiles.app`

