package com.vaultfiles.app.file

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class FileRepository(private val context: Context) {
    val root: File get() = Environment.getExternalStorageDirectory()

    fun hasAllFilesAccess(): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }

    fun permissionIntent(): Intent {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:${context.packageName}")
            }
        } else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
    }

    suspend fun list(directory: File, sort: SortMode): List<FileItem> = withContext(Dispatchers.IO) {
        val files = directory.listFiles()?.map(::FileItem).orEmpty()
        val comparator = when (sort) {
            SortMode.NAME -> compareBy<FileItem>({ !it.isDirectory }, { it.file.name.lowercase(Locale.getDefault()) })
            SortMode.DATE -> compareBy<FileItem> { !it.isDirectory }.thenByDescending { it.modified }
            SortMode.SIZE -> compareBy<FileItem> { !it.isDirectory }.thenByDescending { it.size }
        }
        files.sortedWith(comparator)
    }

    suspend fun search(base: File, query: String, limit: Int = 300): List<FileItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val needle = query.lowercase(Locale.getDefault())
        val result = mutableListOf<FileItem>()
        val stack = ArrayDeque<File>()
        stack.add(base)
        while (stack.isNotEmpty() && result.size < limit) {
            val dir = stack.removeLast()
            dir.listFiles()?.forEach { f ->
                if (result.size >= limit) return@forEach
                if (f.name.lowercase(Locale.getDefault()).contains(needle)) result.add(FileItem(f))
                if (f.isDirectory && !f.name.startsWith(".")) stack.add(f)
            }
        }
        result
    }

    fun mimeType(file: File): String {
        if (file.isDirectory) return "resource/folder"
        val ext = file.extension.lowercase(Locale.getDefault())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun open(file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType(file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun share(file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType(file)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Share file").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    suspend fun delete(file: File): Boolean = withContext(Dispatchers.IO) {
        if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    suspend fun rename(file: File, newName: String): File? = withContext(Dispatchers.IO) {
        val clean = newName.trim().replace("/", "_")
        if (clean.isBlank()) return@withContext null
        val target = File(file.parentFile, clean)
        if (target.exists()) return@withContext null
        if (file.renameTo(target)) target else null
    }

    suspend fun newFolder(parent: File, name: String): File? = withContext(Dispatchers.IO) {
        val clean = name.trim().replace("/", "_")
        if (clean.isBlank()) return@withContext null
        val target = File(parent, clean)
        if (target.exists()) null else if (target.mkdirs()) target else null
    }


    suspend fun copyTo(source: File, destinationDir: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(destinationDir.isDirectory && destinationDir.canWrite()) { "Destination is not writable" }
            if (source.isDirectory) {
                val sourcePath = source.canonicalPath + File.separator
                val destinationPath = destinationDir.canonicalPath + File.separator
                require(!destinationPath.startsWith(sourcePath)) { "A folder cannot be copied into itself" }
            }
            val target = uniqueFile(destinationDir, source.name)
            if (source.isDirectory) {
                val ok = source.copyRecursively(target, overwrite = false)
                if (!ok) error("Copy failed")
            } else {
                source.copyTo(target, overwrite = false)
            }
            target
        }
    }

    suspend fun moveTo(source: File, destinationDir: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(destinationDir.isDirectory && destinationDir.canWrite()) { "Destination is not writable" }
            if (source.isDirectory) {
                val sourcePath = source.canonicalPath + File.separator
                val destinationPath = destinationDir.canonicalPath + File.separator
                require(!destinationPath.startsWith(sourcePath)) { "A folder cannot be moved into itself" }
            }
            val target = uniqueFile(destinationDir, source.name)
            if (source.renameTo(target)) return@runCatching target
            if (source.isDirectory) {
                val ok = source.copyRecursively(target, overwrite = false)
                if (!ok) error("Move failed while copying")
                if (!source.deleteRecursively()) error("Copied, but could not remove the original")
            } else {
                source.copyTo(target, overwrite = false)
                if (!source.delete()) error("Copied, but could not remove the original")
            }
            target
        }
    }

    private fun uniqueFile(parent: File, name: String): File {
        var candidate = File(parent, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(parent, "$stem ($i)$ext")
            i++
        }
        return candidate
    }

    fun downloads(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    fun pictures(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
    fun movies(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
    fun music(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
    fun documents(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
}
