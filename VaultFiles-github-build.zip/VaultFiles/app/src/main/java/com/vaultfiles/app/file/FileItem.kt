package com.vaultfiles.app.file

import java.io.File

data class FileItem(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val size: Long = if (file.isFile) file.length() else 0L,
    val modified: Long = file.lastModified()
)

enum class SortMode { NAME, DATE, SIZE }
