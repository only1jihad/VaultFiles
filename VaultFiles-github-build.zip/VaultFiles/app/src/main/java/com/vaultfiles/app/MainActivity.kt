package com.vaultfiles.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.vaultfiles.app.file.FileItem
import com.vaultfiles.app.file.SortMode
import com.vaultfiles.app.security.BiometricKeyManager
import com.vaultfiles.app.util.formatBytes
import com.vaultfiles.app.util.formatDate
import com.vaultfiles.app.vault.VaultEntry
import java.io.File

class MainActivity : FragmentActivity() {
    private val legacyStorageLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.onResume() }
    private val vm: FileManagerViewModel by viewModels()
    private lateinit var biometricKeys: BiometricKeyManager
    private val biometricEnabledState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        biometricKeys = BiometricKeyManager(this)
        biometricEnabledState.value = biometricKeys.isEnabled

        setContent {
            VaultFilesTheme {
                VaultFilesApp(
                    vm = vm,
                    biometricAvailable = biometricKeys.isAvailable(),
                    biometricEnabled = biometricEnabledState.value,
                    onRequestStoragePermission = ::requestStoragePermission,
                    onEnableBiometric = ::enableBiometric,
                    onBiometricUnlock = ::unlockWithBiometric,
                    onDisableBiometric = {
                        biometricKeys.disable()
                        biometricEnabledState.value = false
                        vm.postMessage("Biometric unlock disabled")
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
        if (::biometricKeys.isInitialized) biometricEnabledState.value = biometricKeys.isEnabled
    }

    override fun onStop() {
        super.onStop()
        vm.lockVault()
    }


    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { startActivity(vm.repository.permissionIntent()) }
                .onFailure { vm.postMessage("Could not open storage permission settings") }
        } else {
            legacyStorageLauncher.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun enableBiometric() {
        val master = vm.masterKeyCopy()
        if (master == null) {
            vm.postMessage("Unlock the vault with your PIN first")
            return
        }
        val cipher = runCatching { biometricKeys.createEnableCipher() }.getOrElse {
            master.fill(0)
            vm.postMessage("Biometric setup is not available on this device")
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher
                if (c == null) {
                    master.fill(0)
                    vm.postMessage("Biometric setup failed")
                    return
                }
                runCatching { biometricKeys.saveWrappedMaster(c, master) }
                    .onSuccess {
                        biometricEnabledState.value = true
                        vm.postMessage("Biometric unlock enabled")
                    }
                    .onFailure { vm.postMessage("Biometric setup failed") }
                master.fill(0)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                master.fill(0)
                if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                    errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_CANCELED
                ) vm.postMessage(errString.toString())
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Enable biometric unlock")
            .setSubtitle("Protect your encrypted vault with your fingerprint or face")
            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel")
            .build()
        prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    private fun unlockWithBiometric() {
        val cipher = biometricKeys.createUnlockCipher()
        if (cipher == null) {
            biometricKeys.disable()
            biometricEnabledState.value = false
            vm.postMessage("Biometric key is unavailable. Use your PIN.")
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher
                val master = c?.let { biometricKeys.unwrapMaster(it) }
                if (master == null) {
                    biometricKeys.disable()
                    biometricEnabledState.value = false
                    vm.postMessage("Biometric unlock failed. Use your PIN.")
                    return
                }
                vm.unlockVaultWithMasterKey(master)
                vm.postMessage("Vault unlocked")
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                    errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_CANCELED
                ) vm.postMessage(errString.toString())
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock VaultFiles")
            .setSubtitle("Authenticate to open your encrypted vault")
            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }
}

private enum class AppTab { FILES, VAULT, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VaultFilesApp(
    vm: FileManagerViewModel,
    biometricAvailable: Boolean,
    biometricEnabled: Boolean,
    onRequestStoragePermission: () -> Unit,
    onEnableBiometric: () -> Unit,
    onBiometricUnlock: () -> Unit,
    onDisableBiometric: () -> Unit
) {
    var tab by remember { mutableStateOf(AppTab.FILES) }
    var searchVisible by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    var renameTarget by remember { mutableStateOf<File?>(null) }
    var deleteTarget by remember { mutableStateOf<File?>(null) }
    var newFolderDialog by remember { mutableStateOf(false) }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    BackHandler(enabled = tab != AppTab.FILES || vm.currentDirectory != vm.repository.root || searchVisible) {
        when {
            searchVisible -> {
                searchVisible = false
                vm.setSearchQuery("")
            }
            tab != AppTab.FILES -> tab = AppTab.FILES
            else -> vm.goUp()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (tab) {
                            AppTab.FILES -> "VaultFiles"
                            AppTab.VAULT -> "Secure Vault"
                            AppTab.SETTINGS -> "Settings"
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    if (tab == AppTab.FILES && vm.currentDirectory != vm.repository.root) {
                        IconButton(onClick = { vm.goUp() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (tab == AppTab.FILES) {
                        IconButton(onClick = { searchVisible = !searchVisible; if (!searchVisible) vm.setSearchQuery("") }) {
                            Icon(if (searchVisible) Icons.Default.Close else Icons.Default.Search, contentDescription = "Search")
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) {
                                Icon(Icons.Default.Sort, contentDescription = "Sort")
                            }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                SortMode.entries.forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text("Sort by ${mode.name.lowercase().replaceFirstChar { it.uppercase() }}") },
                                        onClick = { vm.setSort(mode); sortMenu = false },
                                        leadingIcon = {
                                            if (vm.sortMode == mode) Icon(Icons.Default.Check, contentDescription = null)
                                        }
                                    )
                                }
                            }
                        }
                        IconButton(onClick = { newFolderDialog = true }) {
                            Icon(Icons.Default.CreateNewFolder, contentDescription = "New folder")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == AppTab.FILES,
                    onClick = { tab = AppTab.FILES },
                    icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                    label = { Text("Files") }
                )
                NavigationBarItem(
                    selected = tab == AppTab.VAULT,
                    onClick = { tab = AppTab.VAULT },
                    icon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    label = { Text("Vault") }
                )
                NavigationBarItem(
                    selected = tab == AppTab.SETTINGS,
                    onClick = { tab = AppTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Settings") }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                AppTab.FILES -> FilesScreen(
                    vm = vm,
                    searchVisible = searchVisible,
                    onRequestStoragePermission = onRequestStoragePermission,
                    onRename = { renameTarget = it },
                    onDelete = { deleteTarget = it },
                    onGoToVault = { tab = AppTab.VAULT }
                )
                AppTab.VAULT -> VaultScreen(
                    vm = vm,
                    biometricAvailable = biometricAvailable,
                    biometricEnabled = biometricEnabled,
                    onEnableBiometric = onEnableBiometric,
                    onBiometricUnlock = onBiometricUnlock
                )
                AppTab.SETTINGS -> SettingsScreen(
                    vm = vm,
                    biometricAvailable = biometricAvailable,
                    biometricEnabled = biometricEnabled,
                    onRequestStoragePermission = onRequestStoragePermission,
                    onEnableBiometric = onEnableBiometric,
                    onDisableBiometric = onDisableBiometric
                )
            }
            if (vm.isBusy) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }

    if (newFolderDialog) {
        TextEntryDialog(
            title = "New folder",
            initial = "",
            label = "Folder name",
            confirmText = "Create",
            onDismiss = { newFolderDialog = false },
            onConfirm = { vm.createFolder(it); newFolderDialog = false }
        )
    }

    renameTarget?.let { file ->
        TextEntryDialog(
            title = "Rename",
            initial = file.name,
            label = "New name",
            confirmText = "Rename",
            onDismiss = { renameTarget = null },
            onConfirm = { vm.rename(file, it); renameTarget = null }
        )
    }

    deleteTarget?.let { file ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            icon = { Icon(Icons.Outlined.DeleteForever, contentDescription = null) },
            title = { Text(if (file.isDirectory) "Delete folder?" else "Delete file?") },
            text = {
                Text(
                    if (file.isDirectory) "${file.name} and everything inside it will be permanently deleted."
                    else "${file.name} will be permanently deleted."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.delete(file); deleteTarget = null }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun FilesScreen(
    vm: FileManagerViewModel,
    searchVisible: Boolean,
    onRequestStoragePermission: () -> Unit,
    onRename: (File) -> Unit,
    onDelete: (File) -> Unit,
    onGoToVault: () -> Unit
) {
    val context = LocalContext.current
    val displayFiles = if (vm.searchQuery.isBlank()) vm.files else vm.searchResults
    Column(Modifier.fillMaxSize()) {
        if (!vm.permissionGranted) {
            PermissionCard(onRequestStoragePermission)
        }
        if (searchVisible) {
            OutlinedTextField(
                value = vm.searchQuery,
                onValueChange = vm::setSearchQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search in ${vm.currentDirectory.name.ifBlank { "storage" }}") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
        }

        if (vm.currentDirectory == vm.repository.root && vm.searchQuery.isBlank()) {
            StorageCard(vm)
            QuickFolders(vm)
        }

        PathBar(vm)
        if (vm.transferSource != null) TransferBar(vm)

        if (displayFiles.isEmpty() && !vm.isBusy) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.FolderOff, null, modifier = Modifier.size(52.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(if (vm.searchQuery.isBlank()) "This folder is empty" else "No matching files")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(displayFiles, key = { it.file.absolutePath }) { item ->
                    FileRow(
                        item = item,
                        onClick = {
                            if (item.isDirectory) vm.openDirectory(item.file)
                            else runCatching { vm.repository.open(item.file) }
                                .onFailure { vm.postMessage("No app can open this file") }
                        },
                        onOpen = {
                            if (item.isDirectory) vm.openDirectory(item.file)
                            else runCatching { vm.repository.open(item.file) }
                                .onFailure { vm.postMessage("No app can open this file") }
                        },
                        onLock = {
                            if (!vm.vaultUnlocked) {
                                vm.postMessage("Open the Vault tab and unlock it first")
                                onGoToVault()
                            } else vm.lockFile(item.file)
                        },
                        onCopy = { vm.stageCopy(item.file) },
                        onMove = { vm.stageMove(item.file) },
                        onRename = { onRename(item.file) },
                        onShare = {
                            if (!item.isDirectory) runCatching { vm.repository.share(item.file) }
                                .onFailure { vm.postMessage("Could not share this file") }
                        },
                        onDelete = { onDelete(item.file) }
                    )
                    HorizontalDivider(modifier = Modifier.padding(start = 72.dp), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
private fun TransferBar(vm: FileManagerViewModel) {
    val source = vm.transferSource ?: return
    Surface(color = MaterialTheme.colorScheme.primaryContainer) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(if (vm.transferIsMove) Icons.Outlined.DriveFileMove else Icons.Outlined.ContentCopy, null)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(source.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(if (vm.transferIsMove) "Move to this folder" else "Copy to this folder", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = vm::cancelTransfer) { Text("Cancel") }
            Button(onClick = vm::pasteTransfer) { Text(if (vm.transferIsMove) "Move here" else "Paste") }
        }
    }
}

@Composable
private fun PermissionCard(onRequest: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.FolderOpen, null, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Storage access required", fontWeight = FontWeight.SemiBold)
                Text("Allow VaultFiles to manage files on shared storage.", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRequest) { Text("Allow") }
        }
    }
}

@Composable
private fun StorageCard(vm: FileManagerViewModel) {
    val (total, free) = vm.storageStats()
    val used = (total - free).coerceAtLeast(0L)
    val ratio = if (total > 0L) (used.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Storage, null)
                Spacer(Modifier.width(10.dp))
                Text("Internal storage", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(progress = ratio, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Text("${formatBytes(used)} used of ${formatBytes(total)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun QuickFolders(vm: FileManagerViewModel) {
    val folders = listOf(
        Triple("Downloads", Icons.Outlined.Download, vm.repository.downloads()),
        Triple("Pictures", Icons.Outlined.Image, vm.repository.pictures()),
        Triple("Videos", Icons.Outlined.Movie, vm.repository.movies()),
        Triple("Music", Icons.Outlined.AudioFile, vm.repository.music()),
        Triple("Documents", Icons.Outlined.Description, vm.repository.documents())
    )
    Column {
        Text(
            "Quick access",
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 6.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(folders) { (name, icon, file) ->
                AssistChip(
                    onClick = { if (file.exists()) vm.openDirectory(file) else vm.postMessage("$name folder is unavailable") },
                    label = { Text(name) },
                    leadingIcon = { Icon(icon, null, modifier = Modifier.size(18.dp)) }
                )
            }
        }
    }
}

@Composable
private fun PathBar(vm: FileManagerViewModel) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = vm::goRoot, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Outlined.Home, contentDescription = "Storage root", modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(4.dp))
            Text(
                vm.currentDirectory.absolutePath.removePrefix(vm.repository.root.absolutePath).ifBlank { "/ Internal storage" },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun FileRow(
    item: FileItem,
    onClick: () -> Unit,
    onOpen: () -> Unit,
    onLock: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onRename: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (item.isDirectory) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.size(46.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(fileIcon(item.file), null, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.file.name.ifBlank { "Unnamed" }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                if (item.isDirectory) formatDate(item.modified) else "${formatBytes(item.size)} · ${formatDate(item.modified)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "More") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; onOpen() }, leadingIcon = { Icon(Icons.Outlined.OpenInNew, null) })
                if (!item.isDirectory) {
                    DropdownMenuItem(text = { Text("Lock in vault") }, onClick = { menu = false; onLock() }, leadingIcon = { Icon(Icons.Outlined.Lock, null) })
                    DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; onShare() }, leadingIcon = { Icon(Icons.Outlined.Share, null) })
                }
                DropdownMenuItem(text = { Text("Copy") }, onClick = { menu = false; onCopy() }, leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) })
                DropdownMenuItem(text = { Text("Move") }, onClick = { menu = false; onMove() }, leadingIcon = { Icon(Icons.Outlined.DriveFileMove, null) })
                DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() }, leadingIcon = { Icon(Icons.Outlined.DriveFileRenameOutline, null) })
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() }, leadingIcon = { Icon(Icons.Outlined.Delete, null) })
            }
        }
    }
}

@Composable
private fun VaultScreen(
    vm: FileManagerViewModel,
    biometricAvailable: Boolean,
    biometricEnabled: Boolean,
    onEnableBiometric: () -> Unit,
    onBiometricUnlock: () -> Unit
) {
    when {
        !vm.vaultConfigured -> CreateVaultScreen(vm)
        !vm.vaultUnlocked -> UnlockVaultScreen(vm, biometricAvailable && biometricEnabled, onBiometricUnlock)
        else -> UnlockedVaultScreen(vm, biometricAvailable, biometricEnabled, onEnableBiometric)
    }
}

@Composable
private fun CreateVaultScreen(vm: FileManagerViewModel) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(84.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.EnhancedEncryption, null, modifier = Modifier.size(42.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text("Create your encrypted vault", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Files you lock are encrypted before the original is removed from shared storage.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        PinField(pin, { pin = digitsOnly(it) }, "Create PIN")
        Spacer(Modifier.height(12.dp))
        PinField(confirm, { confirm = digitsOnly(it) }, "Confirm PIN")
        Spacer(Modifier.height(20.dp))
        Button(onClick = { if (vm.createVaultPin(pin, confirm)) { pin = ""; confirm = "" } }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Lock, null)
            Spacer(Modifier.width(8.dp))
            Text("Create secure vault")
        }
        Spacer(Modifier.height(12.dp))
        Text("Keep this PIN safe. VaultFiles does not store your PIN in plain text.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun UnlockVaultScreen(vm: FileManagerViewModel, biometricEnabled: Boolean, onBiometricUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.Lock, null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(16.dp))
        Text("Vault locked", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Enter your PIN to decrypt the vault index.")
        Spacer(Modifier.height(24.dp))
        PinField(pin, { pin = digitsOnly(it) }, "PIN")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (vm.unlockVault(pin)) pin = "" }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
        if (biometricEnabled) {
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onBiometricUnlock, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Fingerprint, null)
                Spacer(Modifier.width(8.dp))
                Text("Unlock with biometrics")
            }
        }
    }
}

@Composable
private fun UnlockedVaultScreen(
    vm: FileManagerViewModel,
    biometricAvailable: Boolean,
    biometricEnabled: Boolean,
    onEnableBiometric: () -> Unit
) {
    var deleteEntry by remember { mutableStateOf<VaultEntry?>(null) }
    Column(Modifier.fillMaxSize()) {
        ElevatedCard(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.VerifiedUser, null, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Vault unlocked", fontWeight = FontWeight.SemiBold)
                    Text("${vm.vaultEntries.size} encrypted ${if (vm.vaultEntries.size == 1) "file" else "files"}", style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = vm::lockVault) { Text("Lock now") }
            }
        }
        if (biometricAvailable && !biometricEnabled) {
            OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Fingerprint, null)
                    Spacer(Modifier.width(10.dp))
                    Text("Enable biometric unlock", Modifier.weight(1f))
                    TextButton(onClick = onEnableBiometric) { Text("Enable") }
                }
            }
        }
        if (vm.vaultEntries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Shield, null, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Your vault is empty", fontWeight = FontWeight.Medium)
                    Text("From Files, choose ⋮ → Lock in vault", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                items(vm.vaultEntries, key = { it.id }) { entry ->
                    VaultRow(entry, onRestore = { vm.restore(entry) }, onDelete = { deleteEntry = entry })
                    HorizontalDivider(Modifier.padding(start = 72.dp), thickness = 0.5.dp)
                }
            }
        }
    }

    deleteEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { deleteEntry = null },
            icon = { Icon(Icons.Outlined.DeleteForever, null) },
            title = { Text("Delete encrypted file?") },
            text = { Text("${entry.name} will be permanently removed from the vault.") },
            confirmButton = { TextButton(onClick = { vm.deleteFromVault(entry); deleteEntry = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteEntry = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VaultRow(entry: VaultEntry, onRestore: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(46.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Lock, null) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text("${formatBytes(entry.size)} · Locked ${formatDate(entry.lockedAt)}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Restore") }, onClick = { menu = false; onRestore() }, leadingIcon = { Icon(Icons.Outlined.Restore, null) })
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() }, leadingIcon = { Icon(Icons.Outlined.DeleteForever, null) })
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    vm: FileManagerViewModel,
    biometricAvailable: Boolean,
    biometricEnabled: Boolean,
    onRequestStoragePermission: () -> Unit,
    onEnableBiometric: () -> Unit,
    onDisableBiometric: () -> Unit
) {
    var changePin by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionLabel("Storage") }
        item {
            SettingsCard(
                icon = Icons.Outlined.FolderOpen,
                title = "All files access",
                subtitle = if (vm.permissionGranted) "Granted" else "Required for full file-manager access",
                action = { TextButton(onClick = onRequestStoragePermission) { Text(if (vm.permissionGranted) "Settings" else "Allow") } }
            )
        }
        item { SectionLabel("Security") }
        item {
            SettingsCard(
                icon = Icons.Outlined.EnhancedEncryption,
                title = "Encrypted vault",
                subtitle = "AES-256-GCM encryption with a PIN + Android Keystore protected master key",
                action = {
                    if (vm.vaultUnlocked) TextButton(onClick = vm::lockVault) { Text("Lock") }
                }
            )
        }
        if (vm.vaultConfigured) {
            item {
                SettingsCard(
                    icon = Icons.Outlined.Password,
                    title = "Change vault PIN",
                    subtitle = "Re-wraps the same vault key; files do not need to be re-encrypted",
                    action = { TextButton(onClick = { changePin = true }) { Text("Change") } }
                )
            }
        }
        if (biometricAvailable) {
            item {
                SettingsCard(
                    icon = Icons.Outlined.Fingerprint,
                    title = "Biometric unlock",
                    subtitle = if (biometricEnabled) "Enabled with Android Keystore" else "Optional fingerprint/face unlock",
                    action = {
                        TextButton(onClick = {
                            if (biometricEnabled) onDisableBiometric()
                            else onEnableBiometric()
                        }) { Text(if (biometricEnabled) "Disable" else "Enable") }
                    }
                )
            }
        }
        item { SectionLabel("Privacy") }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Designed to stay on-device", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("VaultFiles has no network permission, no analytics SDK, and no cloud upload code in this build.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Text("VaultFiles 1.0.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
        }
    }

    if (changePin) ChangePinDialog(vm) { changePin = false }
}

@Composable
private fun SettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    action: @Composable () -> Unit
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            action()
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
}

@Composable
private fun ChangePinDialog(vm: FileManagerViewModel, onDismiss: () -> Unit) {
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change vault PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PinField(oldPin, { oldPin = digitsOnly(it) }, "Current PIN")
                PinField(newPin, { newPin = digitsOnly(it) }, "New PIN")
                PinField(confirm, { confirm = digitsOnly(it) }, "Confirm new PIN")
            }
        },
        confirmButton = {
            TextButton(onClick = { if (vm.changePin(oldPin, newPin, confirm)) onDismiss() }) { Text("Change") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun PinField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 12) onValueChange(it) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = PasswordVisualTransformation(),
        singleLine = true
    )
}

@Composable
private fun TextEntryDialog(
    title: String,
    initial: String,
    label: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        },
        confirmButton = { TextButton(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun digitsOnly(value: String): String = value.filter(Char::isDigit).take(12)

private fun fileIcon(file: File): androidx.compose.ui.graphics.vector.ImageVector {
    if (file.isDirectory) return Icons.Outlined.Folder
    return when (file.extension.lowercase()) {
        "jpg", "jpeg", "png", "webp", "gif", "heic" -> Icons.Outlined.Image
        "mp4", "mkv", "avi", "mov", "webm" -> Icons.Outlined.Movie
        "mp3", "wav", "aac", "m4a", "flac", "ogg" -> Icons.Outlined.AudioFile
        "pdf", "doc", "docx", "txt", "rtf", "xls", "xlsx", "ppt", "pptx", "csv" -> Icons.Outlined.Description
        "apk" -> Icons.Outlined.Android
        "zip", "rar", "7z", "tar", "gz" -> Icons.Outlined.FolderZip
        else -> Icons.Outlined.InsertDriveFile
    }
}

@Composable
private fun VaultFilesTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val scheme = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
