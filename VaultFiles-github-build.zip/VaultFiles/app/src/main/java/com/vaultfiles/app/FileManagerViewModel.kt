package com.vaultfiles.app

import android.app.Application
import android.os.StatFs
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vaultfiles.app.file.FileItem
import com.vaultfiles.app.file.FileRepository
import com.vaultfiles.app.file.SortMode
import com.vaultfiles.app.security.PinStore
import com.vaultfiles.app.vault.VaultEntry
import com.vaultfiles.app.vault.VaultStore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class FileManagerViewModel(application: Application) : AndroidViewModel(application) {
    val repository = FileRepository(application)
    private val pinStore = PinStore(application)
    private val vaultStore = VaultStore(application)

    var currentDirectory by mutableStateOf(repository.root)
        private set
    var files by mutableStateOf<List<FileItem>>(emptyList())
        private set
    var searchResults by mutableStateOf<List<FileItem>>(emptyList())
        private set
    var searchQuery by mutableStateOf("")
        private set
    var sortMode by mutableStateOf(SortMode.NAME)
        private set
    var isBusy by mutableStateOf(false)
        private set
    var permissionGranted by mutableStateOf(repository.hasAllFilesAccess())
        private set
    var message by mutableStateOf<String?>(null)
        private set

    var vaultEntries by mutableStateOf<List<VaultEntry>>(emptyList())
        private set
    var vaultUnlocked by mutableStateOf(false)
        private set
    var transferSource by mutableStateOf<File?>(null)
        private set
    var transferIsMove by mutableStateOf(false)
        private set
    val vaultConfigured: Boolean get() = pinStore.isConfigured

    private var masterKey: ByteArray? = null
    private var searchJob: Job? = null

    init {
        refresh()
    }

    fun onResume() {
        permissionGranted = repository.hasAllFilesAccess()
        refresh()
    }

    fun consumeMessage() {
        message = null
    }

    fun postMessage(text: String) {
        message = text
    }

    fun refresh() {
        viewModelScope.launch {
            isBusy = true
            files = repository.list(currentDirectory, sortMode)
            isBusy = false
        }
    }

    fun openDirectory(file: File) {
        if (!file.isDirectory) return
        currentDirectory = file
        searchQuery = ""
        searchResults = emptyList()
        refresh()
    }

    fun goUp(): Boolean {
        val rootPath = repository.root.canonicalPath
        val currentPath = runCatching { currentDirectory.canonicalPath }.getOrElse { currentDirectory.absolutePath }
        if (currentPath == rootPath) return false
        currentDirectory.parentFile?.let { openDirectory(it) }
        return true
    }

    fun goRoot() {
        openDirectory(repository.root)
    }

    fun setSort(mode: SortMode) {
        sortMode = mode
        refresh()
    }

    fun setSearchQuery(query: String) {
        searchQuery = query
        searchJob?.cancel()
        if (query.isBlank()) {
            searchResults = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(250)
            isBusy = true
            searchResults = repository.search(currentDirectory, query)
            isBusy = false
        }
    }


    fun stageCopy(file: File) {
        transferSource = file
        transferIsMove = false
        message = "Choose a destination folder and tap Paste"
    }

    fun stageMove(file: File) {
        transferSource = file
        transferIsMove = true
        message = "Choose a destination folder and tap Move here"
    }

    fun cancelTransfer() {
        transferSource = null
        transferIsMove = false
    }

    fun pasteTransfer() {
        val source = transferSource ?: return
        if (source.parentFile?.absolutePath == currentDirectory.absolutePath) {
            message = "Source is already in this folder"
            return
        }
        viewModelScope.launch {
            isBusy = true
            val result = if (transferIsMove) repository.moveTo(source, currentDirectory)
            else repository.copyTo(source, currentDirectory)
            result.onSuccess {
                message = if (transferIsMove) "Moved ${source.name}" else "Copied ${source.name}"
                cancelTransfer()
                refresh()
            }.onFailure {
                message = it.message ?: if (transferIsMove) "Move failed" else "Copy failed"
            }
            isBusy = false
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            val created = repository.newFolder(currentDirectory, name)
            message = if (created != null) "Folder created" else "Could not create folder"
            refresh()
        }
    }

    fun rename(file: File, newName: String) {
        viewModelScope.launch {
            val renamed = repository.rename(file, newName)
            message = if (renamed != null) "Renamed" else "Rename failed or name already exists"
            refresh()
        }
    }

    fun delete(file: File) {
        viewModelScope.launch {
            isBusy = true
            val ok = repository.delete(file)
            message = if (ok) "Deleted" else "Delete failed"
            refresh()
            isBusy = false
        }
    }

    fun createVaultPin(pin: String, confirm: String): Boolean {
        if (pin.length < 6 || !pin.all(Char::isDigit)) {
            message = "Use at least a 6-digit PIN"
            return false
        }
        if (pin != confirm) {
            message = "PINs do not match"
            return false
        }
        return runCatching {
            val key = pinStore.create(pin.toCharArray())
            setMasterKey(key)
            viewModelScope.launch { reloadVault() }
            message = "Vault created"
            true
        }.getOrElse {
            message = "Could not create vault"
            false
        }
    }

    fun unlockVault(pin: String): Boolean {
        val key = pinStore.unlock(pin.toCharArray())
        if (key == null) {
            message = "Incorrect PIN"
            return false
        }
        setMasterKey(key)
        viewModelScope.launch { reloadVault() }
        return true
    }

    fun unlockVaultWithMasterKey(key: ByteArray) {
        setMasterKey(key)
        viewModelScope.launch { reloadVault() }
    }

    fun masterKeyCopy(): ByteArray? = masterKey?.copyOf()

    fun lockVault() {
        masterKey?.fill(0)
        masterKey = null
        vaultUnlocked = false
        vaultEntries = emptyList()
    }

    fun changePin(oldPin: String, newPin: String, confirm: String): Boolean {
        if (newPin.length < 6 || !newPin.all(Char::isDigit)) {
            message = "New PIN must be at least 6 digits"
            return false
        }
        if (newPin != confirm) {
            message = "New PINs do not match"
            return false
        }
        val ok = pinStore.changePin(oldPin.toCharArray(), newPin.toCharArray())
        message = if (ok) "PIN changed" else "Current PIN is incorrect"
        return ok
    }

    fun lockFile(file: File) {
        val key = masterKey
        if (key == null) {
            message = "Unlock the Vault first, then lock the file"
            return
        }
        viewModelScope.launch {
            isBusy = true
            val result = vaultStore.lock(file, key)
            if (result.isSuccess) {
                message = if (file.exists()) {
                    "Encrypted copy created, but the original could not be removed. Delete the original manually."
                } else {
                    "${file.name} locked securely"
                }
                reloadVault()
                refresh()
            } else {
                message = result.exceptionOrNull()?.message ?: "Could not lock file"
            }
            isBusy = false
        }
    }

    fun restore(entry: VaultEntry) {
        val key = masterKey ?: return
        viewModelScope.launch {
            isBusy = true
            val result = vaultStore.restore(entry, key)
            message = result.fold(
                onSuccess = { "Restored to ${it.parentFile?.absolutePath ?: "storage"}" },
                onFailure = { it.message ?: "Restore failed" }
            )
            reloadVault()
            refresh()
            isBusy = false
        }
    }

    fun deleteFromVault(entry: VaultEntry) {
        val key = masterKey ?: return
        viewModelScope.launch {
            isBusy = true
            val result = vaultStore.delete(entry, key)
            message = if (result.isSuccess) "Deleted from vault" else "Could not delete from vault"
            reloadVault()
            isBusy = false
        }
    }

    private suspend fun reloadVault() {
        val key = masterKey ?: return
        runCatching { vaultStore.load(key) }
            .onSuccess { vaultEntries = it }
            .onFailure {
                vaultEntries = emptyList()
                message = "Vault index could not be verified. No encrypted data was changed."
            }
    }

    private fun setMasterKey(key: ByteArray) {
        masterKey?.fill(0)
        masterKey = key.copyOf()
        key.fill(0)
        vaultUnlocked = true
    }

    fun storageStats(): Pair<Long, Long> {
        return runCatching {
            val stat = StatFs(repository.root.absolutePath)
            stat.totalBytes to stat.availableBytes
        }.getOrDefault(0L to 0L)
    }

    override fun onCleared() {
        lockVault()
        super.onCleared()
    }
}
