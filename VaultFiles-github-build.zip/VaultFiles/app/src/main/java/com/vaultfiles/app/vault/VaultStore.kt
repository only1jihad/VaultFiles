package com.vaultfiles.app.vault

import android.content.Context
import android.os.Environment
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class VaultStore(private val context: Context) {
    private val vaultDir = File(context.filesDir, "vault").apply { mkdirs() }
    private val indexFile = File(vaultDir, "index.vfi")
    private val random = SecureRandom()

    suspend fun load(masterKey: ByteArray): List<VaultEntry> = withContext(Dispatchers.IO) {
        if (!indexFile.exists()) return@withContext emptyList()
        val plain = decryptSmall(masterKey, indexFile.readBytes())
        val array = JSONArray(String(plain, Charsets.UTF_8))
        buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    VaultEntry(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        originalPath = o.getString("originalPath"),
                        mimeType = o.optString("mimeType", "application/octet-stream"),
                        size = o.optLong("size", 0L),
                        lockedAt = o.optLong("lockedAt", 0L)
                    )
                )
            }
        }
    }

    suspend fun lock(source: File, masterKey: ByteArray): Result<VaultEntry> = withContext(Dispatchers.IO) {
        runCatching {
            require(source.exists() && source.isFile) { "Only files can be locked" }
            val entries = load(masterKey).toMutableList()
            val id = UUID.randomUUID().toString()
            val target = File(vaultDir, "$id.vf")
            val temp = File(vaultDir, "$id.tmp")
            try {
                encryptFile(source, temp, masterKey)
                if (!temp.renameTo(target)) {
                    temp.copyTo(target, overwrite = true)
                    temp.delete()
                }
                val entry = VaultEntry(
                    id = id,
                    name = source.name,
                    originalPath = source.absolutePath,
                    mimeType = mimeType(source),
                    size = source.length(),
                    lockedAt = System.currentTimeMillis()
                )
                entries.add(0, entry)
                save(entries, masterKey)
                if (!source.delete()) {
                    // Encryption succeeded; keep the secure copy even if Android/FS refused source deletion.
                }
                entry
            } catch (e: Exception) {
                temp.delete()
                target.delete()
                throw e
            }
        }
    }

    suspend fun restore(entry: VaultEntry, masterKey: ByteArray): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val source = File(vaultDir, "${entry.id}.vf")
            require(source.exists()) { "Encrypted file is missing" }
            val original = File(entry.originalPath)
            var parent = original.parentFile
            if (parent == null || !parent.exists() || !parent.canWrite()) {
                parent = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "VaultFiles Restored"
                ).apply { mkdirs() }
            }
            val target = uniqueFile(parent, entry.name)
            val temp = File(parent, ".${target.name}.restore_tmp")
            decryptFile(source, temp, masterKey)
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            val entries = load(masterKey).filterNot { it.id == entry.id }
            save(entries, masterKey)
            source.delete()
            target
        }
    }

    suspend fun delete(entry: VaultEntry, masterKey: ByteArray): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val entries = load(masterKey).filterNot { it.id == entry.id }
            val source = File(vaultDir, "${entry.id}.vf")
            if (source.exists() && !source.delete()) error("Could not delete encrypted file")
            save(entries, masterKey)
        }
    }

    private fun save(entries: List<VaultEntry>, masterKey: ByteArray) {
        val array = JSONArray()
        entries.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("name", e.name)
                put("originalPath", e.originalPath)
                put("mimeType", e.mimeType)
                put("size", e.size)
                put("lockedAt", e.lockedAt)
            })
        }
        val encrypted = encryptSmall(masterKey, array.toString().toByteArray(Charsets.UTF_8))
        val temp = File(vaultDir, "index.tmp")
        temp.writeBytes(encrypted)
        if (!temp.renameTo(indexFile)) {
            temp.copyTo(indexFile, overwrite = true)
            temp.delete()
        }
    }

    private fun encryptFile(source: File, dest: File, key: ByteArray) {
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        FileOutputStream(dest).use { fos ->
            BufferedOutputStream(fos).use { bos ->
                bos.write(FILE_MAGIC)
                bos.write(iv.size)
                bos.write(iv)
                CipherOutputStream(bos, cipher).use { cos ->
                    BufferedInputStream(FileInputStream(source)).use { input ->
                        input.copyTo(cos, bufferSize = 1024 * 256)
                    }
                }
            }
        }
    }

    private fun decryptFile(source: File, dest: File, key: ByteArray) {
        FileInputStream(source).use { fis ->
            val bis = BufferedInputStream(fis)
            val magic = ByteArray(FILE_MAGIC.size)
            require(bis.read(magic) == magic.size && magic.contentEquals(FILE_MAGIC)) { "Invalid vault file" }
            val ivLength = bis.read()
            require(ivLength in 12..16) { "Invalid vault IV" }
            val iv = ByteArray(ivLength)
            require(bis.read(iv) == ivLength) { "Invalid vault header" }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
            CipherInputStream(bis, cipher).use { cis ->
                FileOutputStream(dest).use { out -> cis.copyTo(out, bufferSize = 1024 * 256) }
            }
        }
    }

    private fun encryptSmall(key: ByteArray, plain: ByteArray): ByteArray {
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return INDEX_MAGIC + byteArrayOf(iv.size.toByte()) + iv + cipher.doFinal(plain)
    }

    private fun decryptSmall(key: ByteArray, payload: ByteArray): ByteArray {
        require(payload.size > INDEX_MAGIC.size + 13)
        val magic = payload.copyOfRange(0, INDEX_MAGIC.size)
        require(magic.contentEquals(INDEX_MAGIC))
        val ivLength = payload[INDEX_MAGIC.size].toInt() and 0xff
        val ivStart = INDEX_MAGIC.size + 1
        val ivEnd = ivStart + ivLength
        val iv = payload.copyOfRange(ivStart, ivEnd)
        val cipherText = payload.copyOfRange(ivEnd, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(cipherText)
    }

    private fun mimeType(file: File): String {
        val ext = file.extension.lowercase(Locale.getDefault())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun uniqueFile(parent: File, name: String): File {
        var candidate = File(parent, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(parent, "$stem ($i)$ext")
            i++
        }
        return candidate
    }

    companion object {
        private val FILE_MAGIC = byteArrayOf(0x56, 0x46, 0x30, 0x31) // VF01
        private val INDEX_MAGIC = byteArrayOf(0x56, 0x46, 0x49, 0x31) // VFI1
    }
}
