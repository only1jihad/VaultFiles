package com.vaultfiles.app.vault

data class VaultEntry(
    val id: String,
    val name: String,
    val originalPath: String,
    val mimeType: String,
    val size: Long,
    val lockedAt: Long
)
