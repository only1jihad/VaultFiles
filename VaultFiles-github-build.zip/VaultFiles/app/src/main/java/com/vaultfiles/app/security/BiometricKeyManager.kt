package com.vaultfiles.app.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class BiometricKeyManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("vault_biometric", Context.MODE_PRIVATE)

    val isEnabled: Boolean
        get() = prefs.contains(KEY_WRAPPED) && prefs.contains(KEY_IV) && getSecretKey() != null

    fun isAvailable(): Boolean =
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS

    fun createEnableCipher(): Cipher {
        deleteKey()
        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val builder = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        } else {
            @Suppress("DEPRECATION")
            builder.setUserAuthenticationValidityDurationSeconds(-1)
        }

        keyGenerator.init(builder.build())
        val key = keyGenerator.generateKey()
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, key)
        }
    }

    fun saveWrappedMaster(cipher: Cipher, masterKey: ByteArray) {
        val wrapped = cipher.doFinal(masterKey)
        prefs.edit()
            .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(KEY_WRAPPED, Base64.encodeToString(wrapped, Base64.NO_WRAP))
            .apply()
    }

    fun createUnlockCipher(): Cipher? {
        val key = getSecretKey() ?: return null
        val iv = prefs.getString(KEY_IV, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        return runCatching {
            Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            }
        }.getOrNull()
    }

    fun unwrapMaster(cipher: Cipher): ByteArray? {
        val wrapped = prefs.getString(KEY_WRAPPED, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        return runCatching { cipher.doFinal(wrapped) }.getOrNull()
    }

    fun disable() {
        prefs.edit().clear().apply()
        deleteKey()
    }

    private fun getSecretKey(): SecretKey? = runCatching {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        keyStore.getKey(KEY_ALIAS, null) as? SecretKey
    }.getOrNull()

    private fun deleteKey() {
        runCatching {
            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS)
        }
    }

    companion object {
        private const val KEY_ALIAS = "vaultfiles_biometric_master"
        private const val KEY_IV = "iv"
        private const val KEY_WRAPPED = "wrapped"
    }
}
