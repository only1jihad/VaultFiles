package com.vaultfiles.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Protects the random vault master key with two layers:
 * 1) A key derived from the user's PIN using PBKDF2-HMAC-SHA256.
 * 2) A device-bound AES key stored in Android Keystore.
 *
 * The PIN itself is never persisted. Backups are disabled for the app, because
 * the device-bound Keystore key is intentionally not transferable.
 */
class PinStore(context: Context) {
    private val prefs = context.getSharedPreferences("vault_security", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    val isConfigured: Boolean
        get() = prefs.contains(KEY_SALT) && prefs.contains(KEY_WRAPPED_MASTER)

    fun create(pin: CharArray): ByteArray {
        require(pin.size >= MIN_PIN_LENGTH) { "PIN must have at least $MIN_PIN_LENGTH digits" }
        val salt = ByteArray(16).also(random::nextBytes)
        val master = ByteArray(32).also(random::nextBytes)
        val pinKey = derive(pin, salt)
        val pinWrappedMaster = encryptWithRawKey(pinKey, master)
        val deviceWrapped = encryptWithDeviceKey(pinWrappedMaster)
        pinWrappedMaster.fill(0)
        prefs.edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_WRAPPED_MASTER, Base64.encodeToString(deviceWrapped, Base64.NO_WRAP))
            .apply()
        pinKey.fill(0)
        return master
    }

    fun unlock(pin: CharArray): ByteArray? {
        if (!isConfigured) return null
        val saltText = prefs.getString(KEY_SALT, null) ?: return null
        val wrappedText = prefs.getString(KEY_WRAPPED_MASTER, null) ?: return null
        val salt = Base64.decode(saltText, Base64.NO_WRAP)
        val deviceWrapped = Base64.decode(wrappedText, Base64.NO_WRAP)
        val pinWrappedMaster = runCatching { decryptWithDeviceKey(deviceWrapped) }.getOrNull() ?: return null
        val pinKey = derive(pin, salt)
        return try {
            decryptWithRawKey(pinKey, pinWrappedMaster)
        } catch (_: AEADBadTagException) {
            null
        } catch (_: Exception) {
            null
        } finally {
            pinKey.fill(0)
            pinWrappedMaster.fill(0)
        }
    }

    fun changePin(oldPin: CharArray, newPin: CharArray): Boolean {
        val master = unlock(oldPin) ?: return false
        if (newPin.size < MIN_PIN_LENGTH) {
            master.fill(0)
            return false
        }
        val salt = ByteArray(16).also(random::nextBytes)
        val pinKey = derive(newPin, salt)
        val pinWrappedMaster = encryptWithRawKey(pinKey, master)
        val deviceWrapped = encryptWithDeviceKey(pinWrappedMaster)
        prefs.edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_WRAPPED_MASTER, Base64.encodeToString(deviceWrapped, Base64.NO_WRAP))
            .apply()
        master.fill(0)
        pinKey.fill(0)
        pinWrappedMaster.fill(0)
        return true
    }

    private fun derive(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, PBKDF2_ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun encryptWithRawKey(keyBytes: ByteArray, plaintext: ByteArray): ByteArray {
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(plaintext)
    }

    private fun decryptWithRawKey(keyBytes: ByteArray, payload: ByteArray): ByteArray {
        require(payload.size > 12)
        val iv = payload.copyOfRange(0, 12)
        val ciphertext = payload.copyOfRange(12, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun encryptWithDeviceKey(plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateDeviceKey())
        return cipher.iv + cipher.doFinal(plaintext)
    }

    private fun decryptWithDeviceKey(payload: ByteArray): ByteArray {
        require(payload.size > 12)
        val iv = payload.copyOfRange(0, 12)
        val ciphertext = payload.copyOfRange(12, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateDeviceKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun getOrCreateDeviceKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(DEVICE_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                DEVICE_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        const val MIN_PIN_LENGTH = 6
        private const val KEY_SALT = "salt"
        private const val KEY_WRAPPED_MASTER = "wrapped_master"
        private const val DEVICE_KEY_ALIAS = "vaultfiles_device_wrap"
        private const val PBKDF2_ITERATIONS = 600_000
    }
}
